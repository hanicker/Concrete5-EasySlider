<?php 
	defined('C5_EXECUTE') or die(_("Access Denied."));
	//Slides is licensed under the "Apache license":http://www.apache.org/licenses/LICENSE-2.0.
	//See http://slidesjs.com/