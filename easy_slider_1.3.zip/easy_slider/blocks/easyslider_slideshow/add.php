<?php  
defined('C5_EXECUTE') or die(_("Access Denied."));

$this->inc('addedit_inc.php');

?>